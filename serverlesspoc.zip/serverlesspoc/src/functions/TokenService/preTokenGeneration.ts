exports.handler = async (event: any, context: any, callback: any) => {
  event.response = {
    claimsOverrideDetails: {
      claimsToAddOrOverride: {
        clientid: "",
        clientname: "",
      },
    },
  };

  // Return to Amazon Cognito
  callback(null, event);
};
