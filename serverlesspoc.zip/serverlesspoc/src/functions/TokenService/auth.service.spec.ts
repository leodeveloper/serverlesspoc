import { JwksClient } from "jwks-rsa";
let jwt = require("jsonwebtoken");
import AuthService from "./auth.service";
import Logger from "./logger";
import Event from "./event";
//import { LoggerConfiguration, ConsoleSink } from "serilogger";
import "mocha";
import { expect } from "chai";
import sinon from "sinon";

describe("Authorizer", () => {
  //let logger = new LoggerConfiguration().writeTo(new ConsoleSink()).create();
  const logger = new Logger();
  let sut: AuthService;
  beforeEach(() => {
    sut = new AuthService(logger, jwt, JwksClient);
  });

  afterEach(() => {
    sinon.restore();
  });

  it("when token type is not valid", async () => {
    //given
    var event = Event();
    event.type = "TOKEN";
    //when
    try {
      await sut.validate(event);
    } catch (ex : any) {
      //then
      expect(ex.message).to.eql(
        "Expected 'event.type' parameter to have value REQUEST"
      );
    }
  });

  it("when token is not valid and unable to decode", async () => {
    //given
    sinon.stub(jwt, "verify").callsFake(() => {
      return Promise.resolve(null);
    });
    //when
    try {
      await sut.validate(Event());
    } catch (ex : any) {
      //then
      expect(ex.message).contains(
        "Cannot read"
      );
    }
  });

  it("when token is valid should return aws policy", async () => {
    //given
    const decoded = {
      sub: "",
      scope: "aws.cognito.signin.user.admin",
      principalId: "",
      integrationLatency: 161,
      username: "",
    };
    sinon.stub(jwt, "verify").callsFake(() => {
      return Promise.resolve(decoded);
    });
    //when
    const result = await sut.validate(Event());
    //then
    expect(result.policyDocument.Version).to.eql("2012-10-17");
  });
});
