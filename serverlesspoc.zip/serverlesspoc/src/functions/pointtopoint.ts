import {
  Context,
  APIGatewayProxyHandler,
  APIGatewayProxyEvent,
} from "aws-lambda";
import AWS from "aws-sdk";
const lambda = new AWS.Lambda({ region: "eu-west-1" });

const handler: APIGatewayProxyHandler = async (
  event: APIGatewayProxyEvent,
  context: Context
): Promise<any> => {
  const params = {
    FunctionName: "qa-hellopocworld",
    InvocationType: "RequestResponse",
    Payload: JSON.stringify({ tenantid: 123, code: 456 }),
  };

  const LambdaPromise = (params: AWS.Lambda.InvocationRequest) =>
    lambda.invoke(params).promise();

  const response = await LambdaPromise(params);

  console.log(JSON.stringify(response)); //this should return {StatusCode: 202, Payload: ''}

  return {
    statusCode: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
    },
    body: JSON.stringify(`Point to point response compeleted`),
  };
};

export { handler };
